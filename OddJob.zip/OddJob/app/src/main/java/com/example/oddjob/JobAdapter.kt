package com.example.oddjob

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class JobAdapter(
        var context: Context,
        var List:List<Job>,
        private val layout: Int) : RecyclerView.Adapter<JobViewHolder>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): JobViewHolder {
        val v = LayoutInflater.from(parent.context).inflate(layout, parent, false)
        return JobViewHolder(v)
    }

    override fun onBindViewHolder(holder: JobViewHolder, position: Int) {
        holder.bindItems(List[position])
    }

    override fun getItemCount() = List.size
}

class JobViewHolder(view: View) : RecyclerView.ViewHolder(view) {

    private var lattitude: TextView = view.findViewById(R.id.myLattitude)
    private var longitude: TextView = view.findViewById(R.id.myLongitude)
    private var placeId: TextView = view.findViewById(R.id.myPlaceId)

    fun bindItems (item : Job) {
        lattitude.text = item.lattitude.toString()
        longitude.text = item.longitude.toString()
        placeId.text = item.placeId
    }
}