package com.example.oddjob

data class User (
    val email : String ,
    val firstName : String,
    var uuid: String
)