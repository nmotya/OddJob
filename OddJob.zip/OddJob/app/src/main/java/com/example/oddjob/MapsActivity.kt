package com.example.oddjob

import android.animation.ObjectAnimator
import android.app.Activity
import android.app.Dialog
import android.content.ClipData
import android.content.Context
import android.content.DialogInterface
import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.ImageButton
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.gms.maps.CameraUpdateFactory
import com.google.android.gms.maps.GoogleMap
import com.google.android.gms.maps.OnMapReadyCallback
import com.google.android.gms.maps.SupportMapFragment
import com.google.android.gms.maps.model.LatLng
import com.google.android.gms.maps.model.Marker
import com.google.android.gms.maps.model.MarkerOptions
import com.google.android.gms.tasks.Task
import com.google.android.material.floatingactionbutton.FloatingActionButton
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.*
import com.ismaeldivita.chipnavigation.ChipNavigationBar
import java.util.ArrayList
import kotlin.properties.Delegates


var latitudeForMarker by Delegates.notNull<Double>()
var longitudeForMarker by Delegates.notNull<Double>()
var currentPlaceId by Delegates.notNull<String>()


class MapsActivity : AppCompatActivity(), OnMapReadyCallback, DialogInterface.OnDismissListener {
    private val jobList: ArrayList<Job> = ArrayList()

    override fun onDismiss(dialog: DialogInterface?) {
        val newJob =
                Job(
                        latitudeForMarker,
                        longitudeForMarker,
                        "",
                        "",
                        currentPlaceId,
                        FirebaseAuth.getInstance().currentUser?.uid.toString()
                )


        val mDatabase = FirebaseDatabase.getInstance().getReference()
        mDatabase.child("jobs/$currentPlaceId").push().setValue(newJob).addOnCompleteListener { task: Task<Void> ->
            if (task.isSuccessful()) {
                val newMarker = LatLng(latitudeForMarker, longitudeForMarker)
                mMap.addMarker(MarkerOptions().position(newMarker).title("New Marker"))
                mMap.moveCamera(CameraUpdateFactory.newLatLng(newMarker))
            }
        }


        /*val placeIdRef: DatabaseReference = mDatabase.child("jobs").child(currentPlaceId)

        var eventListener: ValueEventListener = object: ValueEventListener {
            override fun onDataChange(dataSnapshot: DataSnapshot) {
                if (!dataSnapshot.exists())
                {
                    mDatabase.child("jobs/$currentPlaceId").push().setValue(newJob).addOnCompleteListener{ task: Task<Void> ->
                        if (task.isSuccessful()){
                            val newMarker = LatLng(latitudeForMarker, longitudeForMarker)
                            mMap.addMarker(MarkerOptions().position(newMarker).title("New Marker"))
                            mMap.moveCamera(CameraUpdateFactory.newLatLng(newMarker))
                        }
                    }
                }
            }
            override fun onCancelled(databaseError: DatabaseError) {
            }
        }
        placeIdRef.addListenerForSingleValueEvent(eventListener);*/


    }

    private lateinit var mMap: GoogleMap

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_maps)
        // Obtain the SupportMapFragment and get notified when the map is ready to be used.
        val mapFragment = supportFragmentManager
            .findFragmentById(R.id.map) as SupportMapFragment
        mapFragment.getMapAsync(this)
    }

    /**
     * Manipulates the map once available.
     * This callback is triggered when the map is ready to be used.
     * This is where we can add markers or lines, add listeners or move the camera. In this case,
     * we just add a marker near Sydney, Australia.
     * If Google Play services is not installed on the device, the user will be prompted to install
     * it inside the SupportMapFragment. This method will only be triggered once the user has
     * installed Google Play services and returned to the app.
     */
    override fun onMapReady(googleMap: GoogleMap) {
        mMap = googleMap

        val logout : Button = findViewById(R.id.logout)
        val myJobs : View = findViewById(R.id.my_job_recycler_view)

        logout.visibility = View.INVISIBLE
        myJobs.visibility = View.INVISIBLE


        val dataReference = FirebaseDatabase.getInstance().getReference("jobs")
        val query = dataReference!!.orderByValue()
        query.addValueEventListener(object : ValueEventListener {
            override fun onDataChange(dataSnapshot: DataSnapshot) {
                for (placeIdSnapshot in dataSnapshot.children) {
                    for (jobSnapshot in placeIdSnapshot.children) {
                        val map : Map<String, String> = jobSnapshot.value as Map<String, String>

                        val newMarker = LatLng(map.get("lattitude") as Double, map.get("longitude") as Double)
                        mMap.addMarker(MarkerOptions().position(newMarker).title(map.get("placeId")))
                        mMap.moveCamera(CameraUpdateFactory.newLatLng(newMarker))

                        val newJob =
                                Job(
                                        map.get("lattitude") as Double,
                                        map.get("longitude") as Double,
                                        "",
                                        "",
                                        map.get("placeId")!!,
                                        FirebaseAuth.getInstance().currentUser?.uid.toString()
                                )
                        jobList.add(newJob)
                    }
                }
            }

            override fun onCancelled(databaseError: DatabaseError) {
            }
        })

        mMap.setOnMarkerClickListener(object: GoogleMap.OnMarkerClickListener {

            override fun onMarkerClick(m: Marker): Boolean {

                var bigDialog = FullScreenDialog()
                val args = Bundle()
                args.putString("string", m.title)
                bigDialog.arguments = args
                bigDialog.show(supportFragmentManager, "bigDialog")
                return true
            }
        })

        val fab : FloatingActionButton = findViewById(R.id.fab)

        fab.setOnClickListener{
            var dialog = CustomDialogFragment()
            dialog.show(supportFragmentManager, "customDialog")
        }




        logout.setOnClickListener{
            FirebaseAuth.getInstance().signOut()
            val intent = Intent(this, MainActivity::class.java)
            startActivity(intent)
        }

        val mapSection : View = findViewById(R.id.mapSection)


        val navBar : ChipNavigationBar = findViewById(R.id.navBar)

        navBar.setOnItemSelectedListener { id ->
            val option = when (id) {
                R.id.myProfile -> {
                    myJobs.visibility = View.INVISIBLE
                    mapSection.visibility = View.INVISIBLE
                    logout.visibility = View.VISIBLE

                }
                R.id.map ->{
                    myJobs.visibility = View.INVISIBLE
                    logout.visibility = View.INVISIBLE
                    mapSection.visibility = View.VISIBLE
                }

                else -> {
                    myJobs.visibility = View.VISIBLE
                    logout.visibility = View.INVISIBLE
                    mapSection.visibility = View.INVISIBLE

                    loadMyJobs(this, this)

                }
            }
        }
    }

}

private fun loadMyJobs(context : Context, activity: Activity) {
    val currentUserId = FirebaseAuth.getInstance().currentUser?.uid
    val dataReference = FirebaseDatabase.getInstance().getReference("jobs")
    val query = dataReference!!.orderByValue()
    val myJobList: ArrayList<Job> = ArrayList()

    query.addValueEventListener(object : ValueEventListener {
        override fun onDataChange(dataSnapshot: DataSnapshot) {
            for (placeIdSnapshot in dataSnapshot.children) {
                for (jobSnapshot in placeIdSnapshot.children) {
                    val map : Map<String, String> = jobSnapshot.value as Map<String, String>
                    if (map.get("userId") == FirebaseAuth.getInstance().currentUser?.uid.toString()){
                        val newJob =
                                Job(
                                        map.get("lattitude") as Double,
                                        map.get("longitude") as Double,
                                        "",
                                        "",
                                        map.get("placeId")!!,
                                        FirebaseAuth.getInstance().currentUser?.uid.toString()
                                )
                        myJobList.add(newJob)
                    }
                }
            }
            val recyclerView: RecyclerView = activity.findViewById(R.id.my_job_recycler_view)
            recyclerView.layoutManager = LinearLayoutManager(context)
            val adapter = MyJobAdapter(myJobList, R.layout.my_job_item)
            recyclerView.adapter = adapter
            adapter!!.notifyDataSetChanged()
        }
        override fun onCancelled(databaseError: DatabaseError) {
        }
    })



}
