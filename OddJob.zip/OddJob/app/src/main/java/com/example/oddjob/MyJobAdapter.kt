package com.example.oddjob

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class MyJobAdapter(
        var List:List<Job>,
        private val layout: Int) : RecyclerView.Adapter<MyJobViewHolder>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MyJobViewHolder {
        val v = LayoutInflater.from(parent.context).inflate(layout, parent, false)
        return MyJobViewHolder(v)
    }

    override fun onBindViewHolder(holder: MyJobViewHolder, position: Int) {
        holder.bindItems(List[position])
    }

    override fun getItemCount() = List.size
}

class MyJobViewHolder(view: View) : RecyclerView.ViewHolder(view) {

    private var lattitude: TextView = view.findViewById(R.id.lattitude)
    private var longitude: TextView = view.findViewById(R.id.longitude)
    private var placeId: TextView = view.findViewById(R.id.placeId)

    fun bindItems (item : Job) {
        lattitude.text = item.lattitude.toString()
        longitude.text = item.longitude.toString()
        placeId.text = item.placeId
    }
}